window.onload = function(){
	$(".contact-card").addClass("cc-noborder");
};
